import React, { useState, useRef } from 'react';
import { analyzeCellImage } from '../services/geminiService';
import { MorphologyResult } from '../types';
import { Upload, Loader2, Microscope, AlertTriangle, CheckCircle, BarChart3 } from 'lucide-react';

export const VisionModule: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<MorphologyResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;
    
    // Extract base64 part
    const base64Data = selectedImage.split(',')[1];
    
    setIsAnalyzing(true);
    try {
      const data = await analyzeCellImage(base64Data);
      setResult(data);
    } catch (error) {
      alert("分析图像失败。请确保 API 密钥已设置且图像有效。");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* Left: Upload Area */}
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-full flex flex-col">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-4">
                <Microscope className="w-5 h-5 text-science-600" />
                图像采集
            </h2>
            
            <div 
                className={`flex-1 border-2 border-dashed rounded-xl flex flex-col items-center justify-center min-h-[300px] transition-colors ${selectedImage ? 'border-slate-300 bg-slate-50' : 'border-science-300 bg-science-50/50 hover:bg-science-50 cursor-pointer'}`}
                onClick={() => !selectedImage && fileInputRef.current?.click()}
            >
                {selectedImage ? (
                    <div className="relative w-full h-full p-2 flex items-center justify-center">
                        <img src={selectedImage} alt="Microscopy" className="max-h-[400px] w-auto rounded shadow-sm object-contain" />
                        <button 
                            onClick={(e) => { e.stopPropagation(); setSelectedImage(null); setResult(null); }}
                            className="absolute top-4 right-4 bg-white/90 p-2 rounded-full shadow-md text-slate-600 hover:text-red-500"
                        >
                            <Upload className="w-4 h-4 rotate-45" />
                        </button>
                    </div>
                ) : (
                    <div className="text-center p-8">
                        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                            <Upload className="w-8 h-8 text-science-500" />
                        </div>
                        <p className="text-slate-600 font-medium">点击上传显微镜图像</p>
                        <p className="text-slate-400 text-sm mt-1">支持 PNG, JPG (最大 5MB)</p>
                    </div>
                )}
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            </div>

            {selectedImage && (
                <div className="mt-6">
                    <button 
                        onClick={handleAnalyze} 
                        disabled={isAnalyzing}
                        className="w-full bg-science-600 hover:bg-science-700 text-white py-3 rounded-lg font-semibold shadow-lg shadow-science-500/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-70"
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="w-5 h-5 animate-spin" /> 正在进行计算机视觉处理...
                            </>
                        ) : (
                            <>
                                <Microscope className="w-5 h-5" /> 分析细胞形态
                            </>
                        )}
                    </button>
                </div>
            )}
        </div>
      </div>

      {/* Right: Analysis Result */}
      <div className="space-y-6">
        {result ? (
            <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden animate-fade-in-up">
                <div className="bg-slate-900 text-white p-6">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                        AI 分析报告
                        {result.anomalyDetected ? 
                            <span className="text-xs bg-red-500/20 text-red-300 border border-red-500/50 px-2 py-0.5 rounded ml-auto">检测到异常</span> :
                            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 px-2 py-0.5 rounded ml-auto">健康培养物</span>
                        }
                    </h3>
                </div>
                
                <div className="p-6 space-y-6">
                    {/* Key Metrics Grid */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">细胞类型预测</span>
                            <div className="text-lg font-bold text-slate-800 mt-1">{result.cellTypePrediction}</div>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">汇合度</span>
                            <div className="text-lg font-bold text-slate-800 mt-1">{result.confluence}%</div>
                            <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
                                <div className="bg-science-500 h-full rounded-full" style={{ width: `${result.confluence}%` }}></div>
                            </div>
                        </div>
                    </div>

                    {/* Stemness Score */}
                    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100">
                         <div className="flex justify-between items-end mb-2">
                            <span className="font-bold text-indigo-900">干性指数</span>
                            <span className="text-2xl font-black text-indigo-600">{result.stemnessScore}/100</span>
                         </div>
                         <div className="w-full bg-white h-3 rounded-full overflow-hidden border border-indigo-100">
                             <div 
                                className="h-full rounded-full bg-gradient-to-r from-indigo-400 to-purple-500 transition-all duration-1000" 
                                style={{ width: `${result.stemnessScore}%` }}
                             ></div>
                         </div>
                         <p className="text-xs text-indigo-600/70 mt-2">
                            分数越高表示基于核质比和克隆紧密度的干性越强，分化程度越低。
                         </p>
                    </div>

                    {/* Detailed Text */}
                    <div>
                        <h4 className="font-semibold text-slate-700 mb-2">形态学评估</h4>
                        <p className="text-slate-600 text-sm leading-relaxed bg-slate-50 p-4 rounded-lg border border-slate-100">
                            {result.morphologyDescription}
                        </p>
                    </div>
                </div>
            </div>
        ) : (
            <div className="h-full bg-slate-50 rounded-xl border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 p-8">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm">
                    <BarChart3 className="w-8 h-8 opacity-50" />
                </div>
                <p>上传图像以查看 AI 分析指标。</p>
            </div>
        )}
      </div>
    </div>
  );
};