import React, { useState, useCallback } from 'react';
import { Factor, ExperimentRun, DoEAnalysisResult } from '../types';
import { analyzeDoEResults } from '../services/geminiService';
import { Plus, Trash2, Play, Beaker, BarChart3, Loader2 } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ZAxis
} from 'recharts';

export const DoEModule: React.FC = () => {
  const [factors, setFactors] = useState<Factor[]>([
    { id: 'f1', name: '温度', min: 36.0, max: 38.0, unit: '°C' },
    { id: 'f2', name: '葡萄糖浓度', min: 10, max: 30, unit: 'mM' }
  ]);
  const [runs, setRuns] = useState<ExperimentRun[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DoEAnalysisResult | null>(null);

  const addFactor = () => {
    const id = `f${factors.length + 1}`;
    setFactors([...factors, { id, name: `因子 ${factors.length + 1}`, min: 0, max: 100, unit: '' }]);
  };

  const removeFactor = (id: string) => {
    setFactors(factors.filter(f => f.id !== id));
  };

  const updateFactor = (id: string, field: keyof Factor, value: string | number) => {
    setFactors(factors.map(f => f.id === id ? { ...f, [field]: value } : f));
  };

  // Simple Generator for Full Factorial (2 Levels)
  const generateDesign = () => {
    if (factors.length === 0) return;
    
    // Generate combinations of Min/Max
    // For n factors, 2^n runs
    const combinations: number[][] = [];
    const numFactors = factors.length;
    const numRuns = Math.pow(2, numFactors);

    for (let i = 0; i < numRuns; i++) {
      const combination: number[] = [];
      for (let j = 0; j < numFactors; j++) {
        // Bitwise trick to get 0 or 1 for each position
        const isMax = (i >> j) & 1;
        combination.push(isMax);
      }
      combinations.push(combination);
    }

    // Add Center Points (Average of min/max)
    // Adding 3 center points for robust statistics
    for(let k=0; k<3; k++) {
       combinations.push(Array(numFactors).fill(0.5));
    }

    const newRuns: ExperimentRun[] = combinations.map((combo, idx) => {
      const runFactors: Record<string, number> = {};
      factors.forEach((f, fIdx) => {
        const val = combo[fIdx];
        if (val === 0.5) {
             runFactors[f.name] = (f.min + f.max) / 2;
        } else {
             runFactors[f.name] = val === 1 ? f.max : f.min;
        }
      });
      return { id: idx + 1, factors: runFactors, yield: undefined, viability: undefined };
    });

    setRuns(newRuns);
    setResult(null);
  };

  const updateRunResult = (id: number, field: 'yield' | 'viability', value: string) => {
    const numVal = parseFloat(value);
    setRuns(runs.map(r => r.id === id ? { ...r, [field]: isNaN(numVal) ? undefined : numVal } : r));
  };

  const fillMockData = () => {
     setRuns(runs.map(run => {
         // Simulate a peak around Temp 37 and Glucose 20
         // Try to match Chinese names if they exist, otherwise fallback
         const temp = run.factors['温度'] || run.factors['Temperature'] || 37;
         const gluc = run.factors['葡萄糖浓度'] || run.factors['Glucose'] || 20;
         
         // Distance from ideal
         const distT = Math.abs(temp - 37);
         const distG = Math.abs(gluc - 20);
         
         const simulatedYield = Math.max(0, 1000000 - (distT * 100000) - (distG * 10000) + (Math.random() * 50000));
         const simulatedViab = Math.min(100, Math.max(0, 95 - (distT * 5) - (distG * 0.5) + (Math.random() * 2)));

         return { ...run, yield: Math.round(simulatedYield), viability: parseFloat(simulatedViab.toFixed(1)) };
     }));
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const data = await analyzeDoEResults(factors, runs);
      setResult(data);
    } catch (e) {
      alert("分析失败。请检查您的 API 密钥和输入数据。");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* 1. Factor Setup */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <Beaker className="w-5 h-5 text-science-600" />
            实验因子 (变量)
          </h2>
          <button onClick={addFactor} className="flex items-center gap-1 text-sm text-science-600 hover:bg-science-50 px-3 py-1.5 rounded-md transition-colors font-medium">
            <Plus className="w-4 h-4" /> 添加因子
          </button>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {factors.map((f) => (
            <div key={f.id} className="p-4 bg-slate-50 rounded-lg border border-slate-100 relative group">
              <button 
                onClick={() => removeFactor(f.id)} 
                className="absolute top-2 right-2 text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase">参数名称</label>
                  <input 
                    type="text" 
                    value={f.name} 
                    onChange={(e) => updateFactor(f.id, 'name', e.target.value)}
                    className="w-full mt-1 px-2 py-1 bg-white border border-slate-200 rounded text-sm focus:border-science-500 outline-none" 
                  />
                </div>
                <div className="flex gap-2">
                   <div className="flex-1">
                      <label className="text-xs font-semibold text-slate-500 uppercase">低水平 (-1)</label>
                      <input 
                        type="number" 
                        value={f.min} 
                        onChange={(e) => updateFactor(f.id, 'min', parseFloat(e.target.value))}
                        className="w-full mt-1 px-2 py-1 bg-white border border-slate-200 rounded text-sm focus:border-science-500 outline-none" 
                      />
                   </div>
                   <div className="flex-1">
                      <label className="text-xs font-semibold text-slate-500 uppercase">高水平 (+1)</label>
                      <input 
                        type="number" 
                        value={f.max} 
                        onChange={(e) => updateFactor(f.id, 'max', parseFloat(e.target.value))}
                        className="w-full mt-1 px-2 py-1 bg-white border border-slate-200 rounded text-sm focus:border-science-500 outline-none" 
                      />
                   </div>
                </div>
                <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase">单位</label>
                    <input 
                      type="text" 
                      value={f.unit} 
                      onChange={(e) => updateFactor(f.id, 'unit', e.target.value)}
                      className="w-full mt-1 px-2 py-1 bg-white border border-slate-200 rounded text-sm focus:border-science-500 outline-none" 
                      placeholder="例如: mM, °C"
                    />
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 flex justify-end">
            <button 
                onClick={generateDesign}
                className="bg-science-600 hover:bg-science-700 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 shadow-md transition-all active:scale-95"
            >
                <Play className="w-4 h-4" /> 生成实验设计表 (DoE)
            </button>
        </div>
      </div>

      {/* 2. Experiment Runs */}
      {runs.length > 0 && (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 animate-fade-in">
           <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-slate-800">数据采集</h2>
            <div className="flex gap-2">
                <button onClick={fillMockData} className="text-xs text-slate-500 underline hover:text-science-600">
                    自动填充模拟数据
                </button>
                <button 
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className="bg-biology-500 hover:bg-biology-600 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 shadow-md transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <BarChart3 className="w-4 h-4" />}
                    分析结果
                </button>
            </div>
          </div>
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="w-full text-sm text-left text-slate-600">
                <thead className="text-xs text-slate-700 uppercase bg-slate-50 border-b border-slate-200">
                    <tr>
                        <th className="px-4 py-3">实验编号</th>
                        {factors.map(f => <th key={f.id} className="px-4 py-3">{f.name} ({f.unit})</th>)}
                        <th className="px-4 py-3 bg-science-50 text-science-900">产量 (细胞/mL)</th>
                        <th className="px-4 py-3 bg-science-50 text-science-900">活率 (%)</th>
                    </tr>
                </thead>
                <tbody>
                    {runs.map((run) => (
                        <tr key={run.id} className="bg-white border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-medium">{run.id}</td>
                            {factors.map(f => (
                                <td key={f.id} className="px-4 py-2">{run.factors[f.name]}</td>
                            ))}
                            <td className="px-4 py-2 bg-science-50/30">
                                <input 
                                    type="number" 
                                    className="w-full bg-white border border-slate-200 rounded px-2 py-1 focus:border-science-500 outline-none"
                                    value={run.yield || ''}
                                    placeholder="0"
                                    onChange={(e) => updateRunResult(run.id, 'yield', e.target.value)}
                                />
                            </td>
                            <td className="px-4 py-2 bg-science-50/30">
                                <input 
                                    type="number" 
                                    className="w-full bg-white border border-slate-200 rounded px-2 py-1 focus:border-science-500 outline-none"
                                    value={run.viability || ''}
                                    placeholder="0-100"
                                    max={100}
                                    onChange={(e) => updateRunResult(run.id, 'viability', e.target.value)}
                                />
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Analysis Results */}
      {result && (
        <div className="grid lg:grid-cols-2 gap-8 animate-fade-in-up">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-600" /> 
                    因子重要性
                </h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={result.variableImportance} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                            <XAxis type="number" domain={[0, 100]} />
                            <YAxis dataKey="name" type="category" width={100} />
                            <RechartsTooltip cursor={{fill: 'transparent'}} />
                            <Bar dataKey="score" fill="#8b5cf6" radius={[0, 4, 4, 0]} barSize={20} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

             <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 rounded-xl shadow-lg">
                <h3 className="text-lg font-bold mb-4 text-emerald-400">AI 优化报告</h3>
                <div className="space-y-4">
                    <p className="text-slate-300 text-sm leading-relaxed border-l-4 border-emerald-500 pl-4">
                        {result.summary}
                    </p>
                    
                    <div className="bg-white/10 p-4 rounded-lg mt-4">
                        <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">预测的最佳参数</h4>
                        <div className="grid grid-cols-2 gap-4">
                            {Object.entries(result.optimalParameters).map(([key, val]) => (
                                <div key={key}>
                                    <span className="text-slate-400 text-xs block">{key}</span>
                                    <span className="text-xl font-mono font-semibold text-white">{val}</span>
                                </div>
                            ))}
                             <div>
                                    <span className="text-slate-400 text-xs block">预测产量</span>
                                    <span className="text-xl font-mono font-semibold text-emerald-400">
                                        {(result.predictedYield / 1000000).toFixed(2)} M/mL
                                    </span>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};