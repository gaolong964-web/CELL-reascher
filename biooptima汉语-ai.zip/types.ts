export interface Factor {
  id: string;
  name: string;
  min: number;
  max: number;
  unit: string;
}

export interface ExperimentRun {
  id: number;
  factors: Record<string, number>; // e.g., { "Temperature": 37, "pH": 7.2 }
  yield?: number; // Cell count or similar
  viability?: number; // Percentage
}

export interface DoEAnalysisResult {
  summary: string;
  optimalParameters: Record<string, number>;
  predictedYield: number;
  variableImportance: { name: string; score: number }[]; // 0-100
}

export interface MorphologyResult {
  cellTypePrediction: string;
  stemnessScore: number; // 0-100
  confluence: number; // 0-100
  morphologyDescription: string;
  anomalyDetected: boolean;
}
