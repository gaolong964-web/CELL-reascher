import { GoogleGenAI, Type } from "@google/genai";
import { DoEAnalysisResult, ExperimentRun, Factor, MorphologyResult } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const analyzeDoEResults = async (
  factors: Factor[],
  runs: ExperimentRun[]
): Promise<DoEAnalysisResult> => {
  if (!apiKey) throw new Error("API Key is missing");

  // Filter only completed runs
  const completedRuns = runs.filter(r => r.yield !== undefined && r.viability !== undefined);

  if (completedRuns.length === 0) {
    throw new Error("No experiment data to analyze.");
  }

  const prompt = `
    You are a bioprocess expert specializing in DoE (Design of Experiments) and Response Surface Methodology.
    Analyze the following experimental data for cell culture optimization.
    
    Factors:
    ${JSON.stringify(factors)}

    Experimental Runs & Results:
    ${JSON.stringify(completedRuns)}

    Task:
    1. Identify the most significant factors affecting Yield and Viability.
    2. Suggest optimal parameters for maximizing both yield and viability (viability > 85% is critical).
    3. Predict the outcome at these optimal settings.
    4. Provide a "Variable Importance" score (0-100) for each factor.
    
    IMPORTANT: Provide the "summary" field in Chinese (Simplified). Keep factor names as provided in the input.
    
    Return the response in JSON format strictly adhering to the schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            optimalParameters: { type: Type.OBJECT }, // Map of factor name to value
            predictedYield: { type: Type.NUMBER },
            variableImportance: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  score: { type: Type.NUMBER }
                }
              }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as DoEAnalysisResult;
    }
    throw new Error("Empty response from AI");
  } catch (error) {
    console.error("DoE Analysis Error:", error);
    throw error;
  }
};

export const analyzeCellImage = async (base64Image: string): Promise<MorphologyResult> => {
  if (!apiKey) throw new Error("API Key is missing");

  const prompt = `
    Analyze this microscopy image of cell culture. 
    1. Identify the cell morphology (e.g., fibroblast-like, epithelial, cobblestone, rounded).
    2. Assess "Stemness" based on morphology (high N/C ratio, tight colonies suggest high stemness). Give a score 0-100.
    3. Estimate confluence (%).
    4. Determine if there are signs of unhealthy differentiation or debris (Anomaly).
    
    IMPORTANT: Provide the "morphologyDescription" and "cellTypePrediction" in Chinese (Simplified).
    
    Return JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          { inlineData: { mimeType: "image/png", data: base64Image } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            cellTypePrediction: { type: Type.STRING },
            stemnessScore: { type: Type.NUMBER },
            confluence: { type: Type.NUMBER },
            morphologyDescription: { type: Type.STRING },
            anomalyDetected: { type: Type.BOOLEAN }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as MorphologyResult;
    }
    throw new Error("Empty response from Vision AI");
  } catch (error) {
    console.error("Image Analysis Error:", error);
    throw error;
  }
};