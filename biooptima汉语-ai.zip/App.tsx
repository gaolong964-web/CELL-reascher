import React, { useState } from 'react';
import { DoEModule } from './components/DoEModule';
import { VisionModule } from './components/VisionModule';
import { Dna, Beaker, Microscope, Activity } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState<'doe' | 'vision'>('doe');

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-science-600 p-2 rounded-lg text-white">
                <Dna className="w-6 h-6" />
            </div>
            <div>
                <h1 className="text-xl font-bold text-slate-900 tracking-tight">BioOptima AI</h1>
                <p className="text-xs text-slate-500 font-medium">先进细胞培养工程</p>
            </div>
          </div>
          <div className="text-xs font-mono text-slate-400 hidden md:block">
            由 Gemini 2.5 Flash 驱动
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        
        {/* Navigation Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white p-1 rounded-xl border border-slate-200 shadow-sm inline-flex">
            <button
              onClick={() => setActiveTab('doe')}
              className={`px-6 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'doe' 
                ? 'bg-science-50 text-science-700 shadow-sm ring-1 ring-science-200' 
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Beaker className="w-4 h-4" />
              DoE 实验优化
            </button>
            <button
              onClick={() => setActiveTab('vision')}
              className={`px-6 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'vision' 
                ? 'bg-science-50 text-science-700 shadow-sm ring-1 ring-science-200' 
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Microscope className="w-4 h-4" />
              形态学视觉分析
            </button>
          </div>
        </div>

        {/* Dynamic Content */}
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {activeTab === 'doe' ? (
             <div className="space-y-6">
                <div className="max-w-3xl mx-auto text-center mb-8">
                    <h2 className="text-2xl font-bold text-slate-900">统计学实验设计</h2>
                    <p className="text-slate-500 mt-2">
                        超越“单次单变量”方法。利用因子设计和响应面法逻辑，揭示 pH、温度和培养基成分之间隐藏的相互作用。
                    </p>
                </div>
                <DoEModule />
             </div>
          ) : (
             <div className="space-y-6">
                 <div className="max-w-3xl mx-auto text-center mb-8">
                    <h2 className="text-2xl font-bold text-slate-900">计算机视觉分析</h2>
                    <p className="text-slate-500 mt-2">
                        利用深度学习直接从显微镜图像评估细胞干性、汇合度和健康状况，无需侵入性采样。
                    </p>
                </div>
                <VisionModule />
             </div>
          )}
        </div>

      </main>

      <footer className="bg-white border-t border-slate-200 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
            <p>&copy; 2024 BioOptima AI. 仅供科研使用。</p>
        </div>
      </footer>
    </div>
  );
}

export default App;